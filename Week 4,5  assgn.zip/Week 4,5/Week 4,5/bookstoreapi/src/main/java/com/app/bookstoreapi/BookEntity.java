package com.app.bookstoreapi;

public class BookEntity {
    
}
